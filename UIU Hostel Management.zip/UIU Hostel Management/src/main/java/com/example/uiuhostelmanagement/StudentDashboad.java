package com.example.uiuhostelmanagement;

import javafx.event.ActionEvent;

public class StudentDashboad {
    public void addMealButtonAction(ActionEvent actionEvent) {
    }

    public void recieveBillButtonAction(ActionEvent actionEvent) {
    }

    public void dailyMealBillsButtonAction(ActionEvent actionEvent) {
    }

    public void logoutButtonAction(ActionEvent actionEvent) {
    }
}
