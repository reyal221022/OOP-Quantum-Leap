package com.example.uiuhostelmanagement;

import javafx.event.ActionEvent;

public class Admin_Dashboard {

    public void registerStudentButtonAction(ActionEvent actionEvent) {
    }

    public void addMealButtonAction(ActionEvent actionEvent) {
    }

    public void newNoticeButtonAction(ActionEvent actionEvent) {
    }

    public void recieveBillButtonAction(ActionEvent actionEvent) {
    }

    public void dailyMealBillsButtonAction(ActionEvent actionEvent) {
    }

    public void billSetupButtonAction(ActionEvent actionEvent) {
    }

    public void studentListMenuAction(ActionEvent actionEvent) {
    }

    public void fullScreenMenuAction(ActionEvent actionEvent) {
    }

    public void settingsButtonAction(ActionEvent actionEvent) {
    }

    public void logoutButtonAction(ActionEvent actionEvent) {
    }

    public void aboutMenuAction(ActionEvent actionEvent) {
    }

    public void hallDetailsRefreshButtonAction(ActionEvent actionEvent) {
    }

    public void hallDetailsEditButtonAction(ActionEvent actionEvent) {
    }

    public void importFromExcelButtonAction(ActionEvent actionEvent) {
    }

    public void closeMenuAction(ActionEvent actionEvent) {
    }
}
