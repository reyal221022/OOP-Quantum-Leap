package com.example.uiuhostelmanagement.util;

public class Test {
    public static void main(String[] args) throws Exception {
        SendEmail.sendMail("rifatibneyousuf@gmail.com","Test","Text Email");
    }
}
