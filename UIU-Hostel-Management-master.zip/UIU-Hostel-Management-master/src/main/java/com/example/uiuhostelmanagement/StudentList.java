package com.example.uiuhostelmanagement;

public class StudentList {
}
