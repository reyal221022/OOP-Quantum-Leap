package com.example.uiuhostelmanagement;

public class ViewHall {
}
