package com.example.uiuhostelmanagement;

public class Admin_Account {

}
